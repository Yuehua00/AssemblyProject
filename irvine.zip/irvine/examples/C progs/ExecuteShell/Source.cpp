
#include <cstdlib>

int main()
{
	system( "dir" );
}